# Indian Dish KB Seed v0.1

362 DRAFT_CURATED implementation seed records.

| # | Dish | Region tags | Category | Batch |
|---:|---|---|---|:---:|
| 1 | Roti | Pan-India | bread_flatbread | A |
| 2 | Phulka | Pan-India | bread_flatbread | A |
| 3 | Tandoori Roti | Pan-India | bread_flatbread | A |
| 4 | Roomali Roti | Pan-India | bread_flatbread | A |
| 5 | Missi Roti | Pan-India | bread_flatbread | A |
| 6 | Makki di Roti | Karnataka, South India, Punjab, North India | bread_flatbread | A |
| 7 | Bajra Roti | Rajasthan, Northwest India | bread_flatbread | A |
| 8 | Jowar Bhakri | Pan-India | bread_flatbread | A |
| 9 | Ragi Roti | Pan-India | bread_flatbread | A |
| 10 | Akki Rotti | Karnataka, South India | bread_flatbread | A |
| 11 | Thepla | Gujarat, Western India | bread_flatbread | A |
| 12 | Methi Thepla | Gujarat, Western India | bread_flatbread | A |
| 13 | Bajra Rotla | Gujarat, Western India, Rajasthan, Northwest India | bread_flatbread | A |
| 14 | Naan | Pan-India | bread_flatbread | A |
| 15 | Butter Naan | Pan-India | bread_flatbread | A |
| 16 | Garlic Naan | Pan-India | bread_flatbread | A |
| 17 | Cheese Naan | Pan-India | bread_flatbread | A |
| 18 | Kulcha | Pan-India | bread_flatbread | A |
| 19 | Amritsari Kulcha | Punjab, North India | bread_flatbread | A |
| 20 | Plain Paratha | Pan-India | bread_flatbread | A |
| 21 | Aloo Paratha | Pan-India | bread_flatbread | A |
| 22 | Gobi Paratha | Pan-India | bread_flatbread | A |
| 23 | Paneer Paratha | Pan-India | bread_flatbread | A |
| 24 | Mooli Paratha | Pan-India | bread_flatbread | A |
| 25 | Methi Paratha | Pan-India | bread_flatbread | A |
| 26 | Sattu Paratha | Bihar, Jharkhand, Eastern India | bread_flatbread | A |
| 27 | Lachha Paratha | Pan-India | bread_flatbread | A |
| 28 | Kerala Parotta | Pan-India | bread_flatbread | A |
| 29 | Malabar Parotta | Kerala, South India | bread_flatbread | A |
| 30 | Puri | Pan-India | bread_flatbread | A |
| 31 | Bhatura | Pan-India | bread_flatbread | A |
| 32 | Luchi | West Bengal, Eastern India | bread_flatbread | A |
| 33 | Bakarkhani | Pan-India | bread_flatbread | A |
| 34 | Sheermal | Pan-India | bread_flatbread | A |
| 35 | Litti | Bihar, Jharkhand, Eastern India | bread_flatbread | A |
| 36 | Steamed Rice | Pan-India | rice_grain | A |
| 37 | Jeera Rice | Pan-India | rice_grain | A |
| 38 | Ghee Rice | Pan-India | rice_grain | A |
| 39 | Lemon Rice | Pan-India | rice_grain | A |
| 40 | Tamarind Rice | Pan-India | rice_grain | A |
| 41 | Coconut Rice | Pan-India | rice_grain | A |
| 42 | Curd Rice | Pan-India | rice_grain | A |
| 43 | Tomato Rice | Pan-India | rice_grain | A |
| 44 | Veg Pulao | Pan-India | rice_grain | A |
| 45 | Peas Pulao | Pan-India | rice_grain | A |
| 46 | Kashmiri Pulao | Kashmir, North India | rice_grain | A |
| 47 | Yakhni Pulao | Kashmir, North India | rice_grain | A |
| 48 | Khichdi | Pan-India | rice_grain | A |
| 49 | Moong Dal Khichdi | Pan-India | rice_grain | A |
| 50 | Masala Khichdi | Pan-India | rice_grain | A |
| 51 | Sabudana Khichdi | Pan-India | rice_grain | A |
| 52 | Ven Pongal | Tamil Nadu, South India | rice_grain | A |
| 53 | Bisi Bele Bath | Karnataka, South India | rice_grain | A |
| 54 | Chicken Biryani | Pan-India | rice_grain | A |
| 55 | Mutton Biryani | Pan-India | rice_grain | A |
| 56 | Egg Biryani | Pan-India | rice_grain | A |
| 57 | Veg Biryani | Pan-India | rice_grain | A |
| 58 | Hyderabadi Chicken Biryani | Pan-India | rice_grain | A |
| 59 | Hyderabadi Mutton Biryani | Pan-India | rice_grain | A |
| 60 | Kolkata Chicken Biryani | West Bengal, Eastern India | rice_grain | A |
| 61 | Kolkata Mutton Biryani | West Bengal, Eastern India | rice_grain | A |
| 62 | Lucknowi Chicken Biryani | Uttar Pradesh, North India | rice_grain | A |
| 63 | Lucknowi Mutton Biryani | Uttar Pradesh, North India | rice_grain | A |
| 64 | Thalassery Chicken Biryani | Kerala, South India | rice_grain | A |
| 65 | Ambur Chicken Biryani | Pan-India | rice_grain | A |
| 66 | Dindigul Chicken Biryani | Pan-India | rice_grain | A |
| 67 | Sindhi Biryani | Pan-India | rice_grain | A |
| 68 | Tehri | Uttar Pradesh, North India | rice_grain | A |
| 69 | Bagara Rice | Pan-India | rice_grain | A |
| 70 | Pulihora | Andhra Pradesh, Telangana, South India | rice_grain | A |
| 71 | Idli | Tamil Nadu, South India | breakfast_snack | A |
| 72 | Mini Idli | Tamil Nadu, South India | breakfast_snack | A |
| 73 | Rava Idli | Tamil Nadu, South India | breakfast_snack | A |
| 74 | Kanchipuram Idli | Tamil Nadu, South India | breakfast_snack | A |
| 75 | Thatte Idli | Tamil Nadu, South India, Karnataka | breakfast_snack | A |
| 76 | Plain Dosa | Tamil Nadu, South India | breakfast_snack | A |
| 77 | Masala Dosa | Tamil Nadu, South India | breakfast_snack | A |
| 78 | Mysore Masala Dosa | Tamil Nadu, South India, Karnataka | breakfast_snack | A |
| 79 | Rava Dosa | Tamil Nadu, South India | breakfast_snack | A |
| 80 | Onion Rava Dosa | Tamil Nadu, South India | breakfast_snack | A |
| 81 | Set Dosa | Tamil Nadu, South India | breakfast_snack | A |
| 82 | Neer Dosa | Tamil Nadu, South India | breakfast_snack | A |
| 83 | Pesarattu | Andhra Pradesh, Telangana, South India | breakfast_snack | A |
| 84 | Adai | Pan-India | breakfast_snack | A |
| 85 | Uttapam | Tamil Nadu, South India | breakfast_snack | A |
| 86 | Onion Uttapam | Tamil Nadu, South India | breakfast_snack | A |
| 87 | Vegetable Uttapam | Tamil Nadu, South India | breakfast_snack | A |
| 88 | Poha | Pan-India | breakfast_snack | A |
| 89 | Kanda Poha | Pan-India | breakfast_snack | A |
| 90 | Indori Poha | Madhya Pradesh, Central India | breakfast_snack | A |
| 91 | Aval Upma | Pan-India | breakfast_snack | A |
| 92 | Upma | Pan-India | breakfast_snack | A |
| 93 | Rava Upma | Pan-India | breakfast_snack | A |
| 94 | Semiya Upma | Pan-India | breakfast_snack | A |
| 95 | Pongal | Tamil Nadu, South India | breakfast_snack | A |
| 96 | Appam | Kerala, South India | breakfast_snack | A |
| 97 | Idiyappam | Kerala, South India | breakfast_snack | A |
| 98 | Puttu | Kerala, South India | breakfast_snack | A |
| 99 | Kadala Puttu | Kerala, South India | breakfast_snack | A |
| 100 | Kuzhi Paniyaram | Pan-India | breakfast_snack | A |
| 101 | Medu Vada | Pan-India | breakfast_snack | A |
| 102 | Sabudana Vada | Pan-India | breakfast_snack | A |
| 103 | Moong Dal Chilla | Pan-India | breakfast_snack | A |
| 104 | Besan Chilla | Pan-India | breakfast_snack | A |
| 105 | Paneer Chilla | Pan-India | breakfast_snack | A |
| 106 | Dhokla | Gujarat, Western India | breakfast_snack | A |
| 107 | Khaman | Gujarat, Western India | breakfast_snack | A |
| 108 | Handvo | Gujarat, Western India | breakfast_snack | A |
| 109 | Khandvi | Gujarat, Western India | breakfast_snack | A |
| 110 | Muthia | Gujarat, Western India | breakfast_snack | A |
| 111 | Dal Tadka | Pan-India | dal_legume | A |
| 112 | Dal Fry | Pan-India | dal_legume | A |
| 113 | Arhar Dal | Pan-India | dal_legume | A |
| 114 | Toor Dal | Pan-India | dal_legume | A |
| 115 | Moong Dal | Pan-India | dal_legume | A |
| 116 | Moong Dal Tadka | Pan-India | dal_legume | A |
| 117 | Masoor Dal | Pan-India | dal_legume | A |
| 118 | Masoor Dal Tadka | Pan-India | dal_legume | A |
| 119 | Chana Dal | Pan-India | dal_legume | A |
| 120 | Chana Dal Tadka | Pan-India | dal_legume | A |
| 121 | Urad Dal | Pan-India | dal_legume | A |
| 122 | Dal Makhani | Punjab, North India | dal_legume | A |
| 123 | Panchmel Dal | Pan-India | dal_legume | A |
| 124 | Dal Baati Style Dal | Pan-India | dal_legume | A |
| 125 | Sambar | Pan-India | dal_legume | A |
| 126 | Rasam | Pan-India | dal_legume | A |
| 127 | Paruppu | Pan-India | dal_legume | A |
| 128 | Pappu | Andhra Pradesh, Telangana, South India | dal_legume | A |
| 129 | Tomato Pappu | Andhra Pradesh, Telangana, South India | dal_legume | A |
| 130 | Palak Pappu | Andhra Pradesh, Telangana, South India | dal_legume | A |
| 131 | Rajma | Pan-India | dal_legume | A |
| 132 | Rajma Masala | Pan-India | dal_legume | A |
| 133 | Chole | Pan-India | dal_legume | A |
| 134 | Chana Masala | Pan-India | dal_legume | A |
| 135 | Kala Chana Curry | Pan-India | dal_legume | A |
| 136 | Lobia Curry | Pan-India | dal_legume | A |
| 137 | Matki Usal | Maharashtra, Western India | dal_legume | A |
| 138 | Moong Usal | Pan-India | dal_legume | A |
| 139 | Misal | Maharashtra, Western India | dal_legume | A |
| 140 | Kadhi | Pan-India | dal_legume | A |
| 141 | Gujarati Kadhi | Pan-India | dal_legume | A |
| 142 | Punjabi Kadhi Pakora | Pan-India | dal_legume | A |
| 143 | Sindhi Kadhi | Pan-India | dal_legume | A |
| 144 | Maharashtrian Amti | Maharashtra, Western India | dal_legume | A |
| 145 | Varan | Maharashtra, Western India | dal_legume | A |
| 146 | Dalma | Odisha, Eastern India | dal_legume | A |
| 147 | Ghugni | Pan-India | dal_legume | A |
| 148 | Cholar Dal | West Bengal, Eastern India | dal_legume | B |
| 149 | Maa ki Dal | Pan-India | dal_legume | B |
| 150 | Kulthi Dal | Pan-India | dal_legume | B |
| 151 | Aloo Gobi | Pan-India | vegetable_dish | B |
| 152 | Aloo Matar | Pan-India | vegetable_dish | B |
| 153 | Aloo Palak | Pan-India | vegetable_dish | B |
| 154 | Aloo Jeera | Pan-India | vegetable_dish | B |
| 155 | Dum Aloo | Pan-India | vegetable_dish | B |
| 156 | Kashmiri Dum Aloo | Kashmir, North India | vegetable_dish | B |
| 157 | Bombay Aloo | Pan-India | vegetable_dish | B |
| 158 | Bhindi Masala | Pan-India | vegetable_dish | B |
| 159 | Bhindi Fry | Pan-India | vegetable_dish | B |
| 160 | Bharwa Bhindi | Pan-India | vegetable_dish | B |
| 161 | Baingan Bharta | Pan-India | vegetable_dish | B |
| 162 | Baingan Masala | Pan-India | vegetable_dish | B |
| 163 | Bharwa Baingan | Pan-India | vegetable_dish | B |
| 164 | Aloo Baingan | Pan-India | vegetable_dish | B |
| 165 | Lauki Sabzi | Pan-India | vegetable_dish | B |
| 166 | Lauki Chana Dal | Pan-India | vegetable_dish | B |
| 167 | Tori Sabzi | Pan-India | vegetable_dish | B |
| 168 | Tinda Masala | Pan-India | vegetable_dish | B |
| 169 | Karela Sabzi | Pan-India | vegetable_dish | B |
| 170 | Bharwa Karela | Pan-India | vegetable_dish | B |
| 171 | Patta Gobi Sabzi | Pan-India | vegetable_dish | B |
| 172 | Gobi Matar | Pan-India | vegetable_dish | B |
| 173 | Matar Mushroom | Pan-India | vegetable_dish | B |
| 174 | Mushroom Masala | Pan-India | vegetable_dish | B |
| 175 | Mushroom Do Pyaza | Pan-India | vegetable_dish | B |
| 176 | Mix Veg Curry | Pan-India | vegetable_dish | B |
| 177 | Veg Korma | Pan-India | vegetable_dish | B |
| 178 | Navratan Korma | Pan-India | vegetable_dish | B |
| 179 | Malai Kofta | Pan-India | vegetable_dish | B |
| 180 | Veg Kofta Curry | Pan-India | vegetable_dish | B |
| 181 | Kofta Curry | Pan-India | vegetable_dish | B |
| 182 | Palak Corn | Pan-India | vegetable_dish | B |
| 183 | Corn Masala | Pan-India | vegetable_dish | B |
| 184 | Methi Malai Matar | Pan-India | vegetable_dish | B |
| 185 | Sarson ka Saag | Punjab, North India | vegetable_dish | B |
| 186 | Palak Saag | Pan-India | vegetable_dish | B |
| 187 | Bathua Saag | Pan-India | vegetable_dish | B |
| 188 | Chana Saag | Pan-India | vegetable_dish | B |
| 189 | Avial | Kerala, South India | vegetable_dish | B |
| 190 | Thoran | Kerala, South India | vegetable_dish | B |
| 191 | Beans Poriyal | Kerala, South India | vegetable_dish | B |
| 192 | Cabbage Poriyal | Kerala, South India | vegetable_dish | B |
| 193 | Beetroot Poriyal | Kerala, South India | vegetable_dish | B |
| 194 | Cabbage Foogath | Pan-India | vegetable_dish | B |
| 195 | Undhiyu | Gujarat, Western India | vegetable_dish | B |
| 196 | Sev Tameta | Gujarat, Western India | vegetable_dish | B |
| 197 | Ringna no Olo | Pan-India | vegetable_dish | B |
| 198 | Karela Fry | Pan-India | vegetable_dish | B |
| 199 | Chokha | Bihar, Jharkhand, Eastern India | vegetable_dish | B |
| 200 | Aloo Chokha | Bihar, Jharkhand, Eastern India | vegetable_dish | B |
| 201 | Baingan Chokha | Bihar, Jharkhand, Eastern India | vegetable_dish | B |
| 202 | Tomato Chokha | Bihar, Jharkhand, Eastern India | vegetable_dish | B |
| 203 | Sukhi Aloo Sabzi | Pan-India | vegetable_dish | B |
| 204 | Paneer Butter Masala | Pan-India | paneer_dairy | B |
| 205 | Kadai Paneer | Pan-India | paneer_dairy | B |
| 206 | Palak Paneer | Pan-India | paneer_dairy | B |
| 207 | Shahi Paneer | Pan-India | paneer_dairy | B |
| 208 | Matar Paneer | Pan-India | paneer_dairy | B |
| 209 | Paneer Tikka Masala | Pan-India | paneer_dairy | B |
| 210 | Paneer Tikka | Pan-India | paneer_dairy | B |
| 211 | Paneer Bhurji | Pan-India | paneer_dairy | B |
| 212 | Malai Paneer | Pan-India | paneer_dairy | B |
| 213 | Paneer Do Pyaza | Pan-India | paneer_dairy | B |
| 214 | Butter Chicken | Pan-India | protein_dish | B |
| 215 | Chicken Curry | Pan-India | protein_dish | B |
| 216 | Kadai Chicken | Pan-India | protein_dish | B |
| 217 | Chicken Korma | Pan-India | protein_dish | B |
| 218 | Chicken Do Pyaza | Pan-India | protein_dish | B |
| 219 | Chicken Saag | Pan-India | protein_dish | B |
| 220 | Chicken Tikka Masala | Pan-India | protein_dish | B |
| 221 | Chicken Tikka | Pan-India | protein_dish | B |
| 222 | Tandoori Chicken | Pan-India | protein_dish | B |
| 223 | Chicken 65 | Pan-India | protein_dish | B |
| 224 | Chicken Chettinad | Pan-India | protein_dish | B |
| 225 | Chicken Sukka | Pan-India | protein_dish | B |
| 226 | Chicken Cafreal | Goa, Western India | protein_dish | B |
| 227 | Chicken Xacuti | Goa, Western India | protein_dish | B |
| 228 | Chicken Vindaloo | Goa, Western India | protein_dish | B |
| 229 | Chicken Kolhapuri | Pan-India | protein_dish | B |
| 230 | Chicken Handi | Pan-India | protein_dish | B |
| 231 | Chicken Changezi | Pan-India | protein_dish | B |
| 232 | Champaran Chicken | Bihar, Jharkhand, Eastern India | protein_dish | B |
| 233 | Chicken Stew | Pan-India | protein_dish | B |
| 234 | Mutton Curry | Pan-India | protein_dish | B |
| 235 | Rogan Josh | Kashmir, North India | protein_dish | B |
| 236 | Mutton Korma | Pan-India | protein_dish | B |
| 237 | Mutton Do Pyaza | Pan-India | protein_dish | B |
| 238 | Mutton Saag | Pan-India | protein_dish | B |
| 239 | Mutton Vindaloo | Goa, Western India | protein_dish | B |
| 240 | Mutton Sukka | Pan-India | protein_dish | B |
| 241 | Mutton Pepper Fry | Pan-India | protein_dish | B |
| 242 | Champaran Mutton | Bihar, Jharkhand, Eastern India | protein_dish | B |
| 243 | Laal Maas | Rajasthan, Northwest India | protein_dish | B |
| 244 | Keema Matar | Pan-India | protein_dish | B |
| 245 | Mutton Keema | Pan-India | protein_dish | B |
| 246 | Nihari | Pan-India | protein_dish | B |
| 247 | Haleem | Pan-India | protein_dish | B |
| 248 | Pork Vindaloo | Goa, Western India | protein_dish | B |
| 249 | Pork Curry | Pan-India | protein_dish | B |
| 250 | Pork with Bamboo Shoot | Northeast India | protein_dish | B |
| 251 | Smoked Pork | Northeast India | protein_dish | B |
| 252 | Fish Curry | Pan-India | protein_dish | B |
| 253 | Bengali Fish Curry | Pan-India | protein_dish | B |
| 254 | Machher Jhol | West Bengal, Eastern India | protein_dish | B |
| 255 | Doi Maach | West Bengal, Eastern India | protein_dish | B |
| 256 | Goan Fish Curry | Goa, Western India | protein_dish | B |
| 257 | Kerala Fish Curry | Pan-India | protein_dish | B |
| 258 | Meen Moilee | Kerala, South India | protein_dish | B |
| 259 | Fish Fry | Pan-India | protein_dish | B |
| 260 | Amritsari Fish | Punjab, North India | protein_dish | B |
| 261 | Prawn Curry | Pan-India | protein_dish | B |
| 262 | Prawn Masala | Pan-India | protein_dish | B |
| 263 | Prawn Fry | Pan-India | protein_dish | B |
| 264 | Egg Curry | Pan-India | protein_dish | B |
| 265 | Anda Bhurji | Pan-India | protein_dish | B |
| 266 | Masala Omelette | Pan-India | protein_dish | B |
| 267 | Egg Roast | Pan-India | protein_dish | B |
| 268 | Samosa | Pan-India | street_food_snack | B |
| 269 | Aloo Samosa | Pan-India | street_food_snack | B |
| 270 | Kachori | Pan-India | street_food_snack | B |
| 271 | Dal Kachori | Pan-India | street_food_snack | B |
| 272 | Pyaz Kachori | Rajasthan, Northwest India | street_food_snack | B |
| 273 | Raj Kachori | Pan-India | street_food_snack | B |
| 274 | Pakora | Pan-India | street_food_snack | B |
| 275 | Onion Pakora | Pan-India | street_food_snack | B |
| 276 | Paneer Pakora | Pan-India | street_food_snack | B |
| 277 | Bread Pakora | Pan-India | street_food_snack | B |
| 278 | Aloo Tikki | Pan-India | street_food_snack | B |
| 279 | Aloo Tikki Chaat | Pan-India | street_food_snack | B |
| 280 | Papdi Chaat | Pan-India | street_food_snack | B |
| 281 | Dahi Papdi Chaat | Pan-India | street_food_snack | B |
| 282 | Dahi Vada | Pan-India | street_food_snack | B |
| 283 | Bhel Puri | Pan-India | street_food_snack | B |
| 284 | Sev Puri | Pan-India | street_food_snack | B |
| 285 | Pani Puri | Pan-India | street_food_snack | B |
| 286 | Dahi Puri | Pan-India | street_food_snack | B |
| 287 | Ragda Pattice | Pan-India | street_food_snack | B |
| 288 | Vada Pav | Maharashtra, Western India | street_food_snack | B |
| 289 | Dabeli | Pan-India | street_food_snack | B |
| 290 | Pav Bhaji | Pan-India | street_food_snack | B |
| 291 | Misal Pav | Maharashtra, Western India | street_food_snack | B |
| 292 | Chole Bhature | Pan-India | street_food_snack | B |
| 293 | Chole Kulche | Pan-India | street_food_snack | B |
| 294 | Aloo Puri | Pan-India | street_food_snack | B |
| 295 | Puri Sabzi | Pan-India | street_food_snack | B |
| 296 | Kathi Roll | Pan-India | street_food_snack | B |
| 297 | Egg Roll | Pan-India | street_food_snack | B |
| 298 | Chicken Roll | Pan-India | street_food_snack | B |
| 299 | Egg Chicken Roll | Pan-India | street_food_snack | B |
| 300 | Paneer Roll | Pan-India | street_food_snack | B |
| 301 | Veg Roll | Pan-India | street_food_snack | B |
| 302 | Frankie | Pan-India | street_food_snack | B |
| 303 | Veg Momos | Pan-India | street_food_snack | B |
| 304 | Chicken Momos | Pan-India | street_food_snack | B |
| 305 | Fried Momos | Pan-India | street_food_snack | B |
| 306 | Tandoori Momos | Pan-India | street_food_snack | B |
| 307 | Chowmein | Pan-India | street_food_snack | B |
| 308 | Veg Chowmein | Pan-India | street_food_snack | B |
| 309 | Hakka Noodles | Pan-India | street_food_snack | B |
| 310 | Chilli Potato | Pan-India | street_food_snack | B |
| 311 | Manchurian | Pan-India | street_food_snack | B |
| 312 | Chilli Paneer | Pan-India | street_food_snack | B |
| 313 | Bun Maska | Pan-India | street_food_snack | B |
| 314 | Gulab Jamun | Pan-India | sweet | B |
| 315 | Kala Jamun | Pan-India | sweet | B |
| 316 | Rasgulla | West Bengal, Eastern India | sweet | B |
| 317 | Rajbhog | Pan-India | sweet | B |
| 318 | Rasmalai | Pan-India | sweet | B |
| 319 | Sandesh | West Bengal, Eastern India | sweet | B |
| 320 | Mishti Doi | West Bengal, Eastern India | sweet | B |
| 321 | Jalebi | Pan-India | sweet | B |
| 322 | Imarti | Pan-India | sweet | B |
| 323 | Balushahi | Pan-India | sweet | B |
| 324 | Kaju Katli | Pan-India | sweet | B |
| 325 | Besan Ladoo | Pan-India | sweet | B |
| 326 | Motichoor Ladoo | Pan-India | sweet | B |
| 327 | Boondi Ladoo | Pan-India | sweet | B |
| 328 | Atta Ladoo | Pan-India | sweet | B |
| 329 | Til Ladoo | Pan-India | sweet | B |
| 330 | Nariyal Ladoo | Pan-India | sweet | B |
| 331 | Peda | Pan-India | sweet | B |
| 332 | Milk Cake | Pan-India | sweet | B |
| 333 | Kalakand | Pan-India | sweet | B |
| 334 | Barfi | Pan-India | sweet | B |
| 335 | Coconut Barfi | Pan-India | sweet | B |
| 336 | Mysore Pak | Karnataka, South India | sweet | B |
| 337 | Soan Papdi | Pan-India | sweet | B |
| 338 | Gajar Halwa | Pan-India | sweet | B |
| 339 | Sooji Halwa | Pan-India | sweet | B |
| 340 | Moong Dal Halwa | Pan-India | sweet | B |
| 341 | Kheer | Pan-India | sweet | B |
| 342 | Rice Kheer | Pan-India | sweet | B |
| 343 | Phirni | Pan-India | sweet | B |
| 344 | Payasam | Pan-India | sweet | B |
| 345 | Seviyan Kheer | Pan-India | sweet | B |
| 346 | Shrikhand | Pan-India | sweet | C |
| 347 | Basundi | Pan-India | sweet | C |
| 348 | Malpua | Pan-India | sweet | C |
| 349 | Thekua | Bihar, Jharkhand, Eastern India | sweet | C |
| 350 | Masala Chai | Pan-India | beverage | C |
| 351 | Milk Tea | Pan-India | beverage | C |
| 352 | Filter Coffee | Pan-India | beverage | C |
| 353 | Lassi | Pan-India | beverage | C |
| 354 | Sweet Lassi | Pan-India | beverage | C |
| 355 | Chaas | Pan-India | beverage | C |
| 356 | Nimbu Pani | Pan-India | beverage | C |
| 357 | Sattu Sharbat | Bihar, Jharkhand, Eastern India | beverage | C |
| 358 | Eromba | Manipur, Northeast India | regional_specialty | C |
| 359 | Singju | Manipur, Northeast India | regional_specialty | C |
| 360 | Dal Pitha | Bihar, Jharkhand, Eastern India | regional_specialty | C |
| 361 | Dhuska | Bihar, Jharkhand, Eastern India | regional_specialty | C |
| 362 | Pittha | Bihar, Jharkhand, Eastern India | regional_specialty | C |