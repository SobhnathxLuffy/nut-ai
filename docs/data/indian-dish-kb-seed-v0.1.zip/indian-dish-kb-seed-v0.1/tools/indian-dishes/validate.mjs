#!/usr/bin/env node
import fs from "node:fs";
const file=process.argv[2]; if(!file){console.error("Usage: node validate.mjs <seed.json>");process.exit(2);}
const rows=JSON.parse(fs.readFileSync(file,"utf8")); const errors=[]; const warnings=[]; const ids=new Set(); const names=new Set(); let pending=0;
for(const [i,r] of rows.entries()){
 if(!r.id||!r.canonicalName)errors.push(`record[${i}]: missing id/name`);
 if(ids.has(r.id))errors.push(`duplicate id ${r.id}`); ids.add(r.id);
 const nk=r.canonicalName.toLowerCase(); if(names.has(nk))errors.push(`duplicate name ${r.canonicalName}`); names.add(nk);
 if(!r.recipeTemplate?.ingredientSlots?.length)errors.push(`${r.id}: no ingredient slots`);
 for(const s of r.recipeTemplate?.ingredientSlots??[]){ if(s.nutritionMapping?.mappingStatus!=="mapped")pending++; const x=s.amountPrior?.range;if(!Array.isArray(x)||x.length!==2||x[0]<0||x[1]<x[0])errors.push(`${r.id}: bad prior ${s.label}`); }
 if(!r.portionModel?.strategies?.length)errors.push(`${r.id}: no portion strategy`);
 if(!r.uncertaintyModel?.highImpactUnknowns?.length)warnings.push(`${r.id}: no high impact unknown`);
}
const map=new Map(rows.map(r=>[r.id,r]));
for(const r of rows){if(r.parentDishId&&!map.has(r.parentDishId))errors.push(`${r.id}: missing parent`);const seen=new Set([r.id]);let p=r.parentDishId;while(p){if(seen.has(p)){errors.push(`${r.id}: inheritance cycle`);break;}seen.add(p);p=map.get(p)?.parentDishId??null;}}
console.log(JSON.stringify({records:rows.length,errors:errors.length,warnings:warnings.length,pendingIngredientMappings:pending,status:errors.length?"FAIL":"PASS"},null,2));
if(errors.length){console.error(errors.join("\n"));process.exit(1);}
