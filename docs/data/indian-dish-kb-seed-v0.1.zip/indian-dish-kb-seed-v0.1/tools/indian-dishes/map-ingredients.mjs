#!/usr/bin/env node
console.error("Seed scaffold only: wire this to the real Nut AI IFCT/USDA adapters. Do not invent IDs.");process.exit(1);
