#!/usr/bin/env node
console.error("Verification gate: compile only mapped/reviewed dish templates.");process.exit(1);
