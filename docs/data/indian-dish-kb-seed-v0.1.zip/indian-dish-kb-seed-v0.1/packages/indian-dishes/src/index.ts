export * from "./types";
export const normalizeDishSearch=(v:string)=>v.normalize("NFKD").toLowerCase().replace(/[^a-z0-9\s-]/g," ").replace(/\s+/g," ").trim();
