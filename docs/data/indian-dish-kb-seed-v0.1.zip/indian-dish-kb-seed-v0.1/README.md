# Indian Dish Knowledge Base Seed v0.1

**362 detailed DRAFT_CURATED dish records** for the Nut AI India-first dish layer.

This is deliberately not a fixed-calorie lookup. Nutrition should resolve as:
`dish -> recipe components -> exact IFCT/USDA ingredient rows -> cooked yield -> serving fraction -> totals`.

## Included
- detailed JSON corpus
- CSV review catalogue
- human-readable catalogue
- TypeScript package skeleton
- structural validator
- stats tool
- integration manifest
- starter resolver golden cases

## Validation
`node tools/indian-dishes/validate.mjs seed/indian-dishes.seed.v0.1.json`

Current counts:
- records: 362
- batch A: 147
- batch B: 198
- batch C: 17
- pending exact ingredient mappings: 1441

All records remain DRAFT_CURATED until exact ingredient mappings, recipe/yield/portion evidence, sanity testing and licensing review are complete.
